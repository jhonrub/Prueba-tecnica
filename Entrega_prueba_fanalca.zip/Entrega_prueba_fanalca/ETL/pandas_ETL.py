#instalar desde consola:
# pip install pandas
# pip install SQLAlchemy
# pip install psycopg2
# pip install matplotlib
# pip install seaborn

import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError

# 1. Extracción: Leer datos desde el archivo CSV
df = pd.read_csv('netflix.csv', sep=';', encoding='utf-8')

# 2. Transformación: Limpieza y normalización de datos

# Eliminar duplicados
df.drop_duplicates(inplace=True)

# Limpiar datos nulos en columnas críticas
df.dropna(subset=['show_id', 'title', 'release_year'], inplace=True)

# Normalizar formatos de fechas (date_added) - Convertir a formato DATE
df['date_added'] = pd.to_datetime(df['date_added'], format='%d/%m/%Y', errors='coerce')

# Crear entidades únicas para Director, Country, Genre, y crear relaciones muchos-a-muchos
directors = df['director'].str.split(',', expand=True).stack().str.strip().unique()
countries = df['country'].str.split(',', expand=True).stack().str.strip().unique()
genres = df['listed_in'].str.split(',', expand=True).stack().str.strip().unique()
casting = df['casting'].str.split(',', expand=True).stack().str.strip().unique()

directors_df = pd.DataFrame(directors, columns=['name']).dropna()
countries_df = pd.DataFrame(countries, columns=['country_name']).dropna()
genres_df = pd.DataFrame(genres, columns=['genre_name']).dropna()
casting_df = pd.DataFrame(casting, columns=['casting_name']).dropna()

# 3. Carga: Conectar a PostgreSQL y cargar los datos en las tablas

# Configurar la conexión a PostgreSQL
DATABASE_URL = "postgresql://postgres:esteban13*@localhost:5432/netflix_db1"
engine = create_engine(DATABASE_URL)

# Cargar las entidades únicas primero
directors_df.to_sql('director', engine, if_exists='append', index=False)
countries_df.to_sql('country', engine, if_exists='append', index=False)
genres_df.to_sql('genre', engine, if_exists='append', index=False)
casting_df.to_sql('casting', engine, if_exists='append', index=False)

# Ahora insertar los datos principales en la tabla 'show'
df_shows = df[['show_id', 'title', 'release_year', 'date_added', 'type', 'rating', 'duration', 'description']]
df_shows.to_sql('show', engine, if_exists='append', index=False)



print("Proceso ETL completado con éxito.")