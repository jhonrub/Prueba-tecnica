import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine
from tkinter import Tk, Listbox, MULTIPLE, Button, END

# Configuración de estilo para gráficos
sns.set(style="whitegrid")

# Conectar a PostgreSQL y leer los datos
DATABASE_URL = "postgresql://postgres:esteban13*@localhost:5432/netflix_db1"
engine = create_engine(DATABASE_URL)

# Leer las tablas necesarias desde la base de datos
df_show = pd.read_sql('SELECT * FROM show', engine)
df_show_genre = pd.read_sql('SELECT sg.show_id, g.genre_name FROM show_genre sg JOIN genre g ON sg.genre_id = g.genre_id', engine)
df_show_country = pd.read_sql('SELECT sc.show_id, c.country_name FROM show_country sc JOIN country c ON sc.country_id = c.country_id', engine)

# Ventana 1: Selección de Géneros
def show_genre_graph(selected_genres):
    if selected_genres:
        df_show_genre_filtered = df_show_genre[df_show_genre['genre_name'].isin(selected_genres)]
    else:
        df_show_genre_filtered = df_show_genre

    genre_counts = df_show_genre_filtered['genre_name'].value_counts()

    plt.figure(figsize=(12, 8))
    plt.bar(genre_counts.index, genre_counts.values, label='Conteo de Shows por Género')
    plt.xlabel('Género')
    plt.ylabel('Cantidad de Shows')
    plt.title('Cantidad de Shows por Género en Netflix')
    plt.xticks(rotation=45, ha='right', fontsize=10)
    plt.legend(title='Género')
    plt.tight_layout()
    plt.show()

def select_genres():
    def on_submit():
        selected_genres = [listbox.get(i) for i in listbox.curselection()]
        show_genre_graph(selected_genres)
        root.destroy()

    root = Tk()
    root.title("Seleccione los Géneros")
    listbox = Listbox(root, selectmode=MULTIPLE)
    genres = df_show_genre['genre_name'].unique()
    for genre in genres:
        listbox.insert(END, genre)
    listbox.pack()

    submit_btn = Button(root, text="Generar Gráfico", command=on_submit)
    submit_btn.pack()
    root.mainloop()

# Ventana 2: Selección de Países
def show_country_graph(selected_countries):
    if selected_countries:
        df_show_country_filtered = df_show_country[df_show_country['country_name'].isin(selected_countries)]
    else:
        df_show_country_filtered = df_show_country

    df_show_country_merged = pd.merge(df_show, df_show_country_filtered, on='show_id')
    country_distribution = df_show_country_merged.groupby('country_name').size().reset_index(name='count').sort_values(by='count', ascending=False)

    plt.figure(figsize=(14, 8))
    sns.barplot(data=country_distribution, x='country_name', y='count', palette='viridis')
    plt.title('Distribución de la Producción de Contenidos en Distintos Países')
    plt.xlabel('País')
    plt.ylabel('Número de Shows')
    plt.xticks(rotation=60, ha='right', fontsize=9)
    plt.gca().margins(x=0.01)
    plt.show()

def select_countries():
    def on_submit():
        selected_countries = [listbox.get(i) for i in listbox.curselection()]
        show_country_graph(selected_countries)
        root.destroy()

    root = Tk()
    root.title("Seleccione los Países")
    listbox = Listbox(root, selectmode=MULTIPLE)
    countries = df_show_country['country_name'].unique()
    for country in countries:
        listbox.insert(END, country)
    listbox.pack()

    submit_btn = Button(root, text="Generar Gráfico", command=on_submit)
    submit_btn.pack()
    root.mainloop()

# Ventana 3: Selección de Años
def show_trend_graph(selected_years):
    if selected_years:
        df_show_filtered = df_show[df_show['release_year'].isin(selected_years)]
    else:
        df_show_filtered = df_show

    content_trend = df_show_filtered.groupby(['release_year', 'type']).size().reset_index(name='count')

    plt.figure(figsize=(14, 8))
    sns.lineplot(data=content_trend, x='release_year', y='count', hue='type', marker='o')
    plt.title('Tendencias en la Producción de Películas vs. Programas de Televisión')
    plt.xlabel('Año de Lanzamiento')
    plt.ylabel('Número de Shows')
    plt.legend(title='Tipo de Contenido')
    plt.show()

def select_years():
    def on_submit():
        selected_years = [int(listbox.get(i)) for i in listbox.curselection()]
        show_trend_graph(selected_years)
        root.destroy()

    root = Tk()
    root.title("Seleccione los Años")
    listbox = Listbox(root, selectmode=MULTIPLE)
    years = df_show['release_year'].unique()
    for year in sorted(years):
        listbox.insert(END, year)
    listbox.pack()

    submit_btn = Button(root, text="Generar Gráfico", command=on_submit)
    submit_btn.pack()
    root.mainloop()

# Llamar a las ventanas
select_genres()
select_countries()
select_years()
