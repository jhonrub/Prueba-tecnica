import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError

# Conectar a la base de datos PostgreSQL
DATABASE_URL = "postgresql://postgres:esteban13*@localhost:5432/netflix_db1"
engine = create_engine(DATABASE_URL)

# Cargar el archivo CSV de Netflix
df = pd.read_csv('netflix.csv', sep=';', encoding='utf-8')

# Procesar los datos para la tabla intermedia de relacion show_casting
df['casting'] = df['casting'].str.split(', ')  
df_show_casting = df.explode('casting').dropna(subset=['casting'])

# Cargar los miembros del cast desde la base de datos
casting_df = pd.read_sql('SELECT * FROM casting', engine)

# Merge para obtener los IDs del cast usando los nombres correctos de columna
df_show_casting = df_show_casting.merge(casting_df, left_on='casting', right_on='casting_name', how='inner')

# Seleccionar solo las columnas necesarias para la tabla de relación
show_casting_df = df_show_casting[['show_id', 'casting_id']].drop_duplicates()

# Insertar datos en la tabla de relación show_casting
try:
    if not show_casting_df.empty:
        show_casting_df.to_sql('show_casting', engine, if_exists='append', index=False)
        print("Datos insertados correctamente en show_casting.")
    else:
        print("El DataFrame show_casting_df está vacío. Verifique sus datos.")
except IntegrityError as e:
    print(f"Error de integridad en show_casting: {e}")
