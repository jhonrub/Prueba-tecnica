--KPI'S:

--Número Total de Shows por Tipo:
SELECT type, COUNT(*) as total_shows 
FROM show 
GROUP BY type;

--Distribución de Shows por Género:
SELECT g.genre_name, COUNT(*) as total_shows 
FROM show_genre sg 
JOIN genre g ON sg.genre_id = g.genre_id 
GROUP BY g.genre_name 
ORDER BY total_shows DESC;

--Número de Shows por País de Producción:
SELECT c.country_name, COUNT(*) as total_shows 
FROM show_country sc 
JOIN country c ON sc.country_id = c.country_id 
GROUP BY c.country_name 
ORDER BY total_shows DESC;

--Tendencia de Producción Anual:
SELECT release_year, type, COUNT(*) as total_shows 
FROM show 
GROUP BY release_year, type 
ORDER BY release_year ASC;

--Duración Media de Shows:
SELECT type, AVG(CAST(SPLIT_PART(duration, ' ', 1) AS INTEGER)) as avg_duration 
FROM show 
WHERE duration LIKE '%min%'  -- Para películas
GROUP BY type;

--Número de Shows por Calificación:
SELECT rating, COUNT(*) as total_shows 
FROM show 
GROUP BY rating 
ORDER BY total_shows DESC;